/*! jQuery Flex Tree 1.2.0 2020-08-19 */ ! function(a) {
    var b = "flexTree",
        c = {};
    a.fn[b] = function(b) {
        b = a.extend(!0, {
            id: void 0,
            targetElement: a(this),
            type: void 0,
            debug: !1,
            name: "flex_tree",
            items: {},
            className: "flex-tree",
            buildTree: !0,
            collapsed: !1,
            collapsable: !0,
            addControlOnParent: !0,
            threeState: !0
        }, c, b), !1 === b.collapsable && (b.collapsed = !1), !1 === b.addControlOnParent && (b.threeState = !1);
        var d;
        if (b.buildTree) {
            d = a("<ul/>").attr("class", b.className).attr("id", b.id);
            var e = function(b) {
                b = a.extend(!0, {
                    items: {},
                    ul: d,
                    collapsed: !1,
                    collapsable: !0,
                    addControlOnParent: !0,
                    threeState: !0
                }, b), a.each(b.items, function(c, d) {
                    if ("object" == typeof d.childrens && d.childrens.length) {
                        var f = a("<li/>");
                        !b.addControlOnParent || "checkbox" !== b.type && "radio" !== b.type || f.append(a("<input/>").attr("type", b.type).attr("name", "radio" === b.type || !1 === b.threeState ? d.name || b.name : d.name).attr("name", d.name).attr("value", d.value).attr("class", "node").attr("id", d.id).prop("checked", d.checked)), f.append(a('<span class="node"/> ').addClass(b.collapsable ? b.collapsed ? "open" : "closed" : "").append(a("<label/>").append(d.label).attr("class", "node")));
                        var g = a("<ul/>");
                        b.ul.append(f), f.append(g), !0 === b.collapsed && g.hide(), e({
                            items: d.childrens,
                            name: b.name,
                            ul: g,
                            collapsed: b.collapsed,
                            collapsable: b.collapsable,
                            type: b.type,
                            addControlOnParent: b.addControlOnParent,
                            threeState: b.threeState
                        })
                    } else b.ul.append(a("<li/>").append(a("<label/>").append("undefined" != typeof b.type ? a("<input/>").attr("type", b.type).attr("name", "checkbox" === b.type ? d.name || b.name : b.name).attr("value", d.value).attr("class", "leaf").attr("id", d.id).prop("checked", d.checked) : void 0).append(d.label)))
                })
            };
            e(b), a(b.targetElement).append(d)
        } else d = b.targetElement, d.addClass(b.className);
        if (b.collapsable && a("li span.node", d).on("click", function(b) {
                a(this).toggleClass("closed").toggleClass("open").next().toggle(200)
            }), b.threeState && "checkbox" === b.type) {
            a('input[type="checkbox"].node', d).on("click", function(b) {
                a(this).removeClass("indeterminate").prop("indeterminate", !1);
                var c = a(this);
                c.parent().find('ul input[type="checkbox"]').each(function() {
                    a(this).prop("checked", c.prop("checked")).prop("indeterminate", !1).removeClass("indeterminate")
                })
            });
            var f = function() {
                var b = a(this).closest("ul").prevAll('input[type="checkbox"].node');
                if (b.length) {
                    a(this).prop("checked") || b.prop("checked", !1);
                    var c = a(this).prop("checked"),
                        d = a(this).prop("checked");
                    a(this).closest("li").siblings("li").find("input:first").each(function() {
                        a(this).prop("checked") && !0 !== a(this).prop("indeterminate") || (c = !1), (a(this).prop("checked") || !0 === a(this).prop("indeterminate")) && (d = !0)
                    }), d || !0 === a(this).prop("indeterminate") ? b.addClass("indeterminate").prop("indeterminate", !0) : b.removeClass("indeterminate").prop("indeterminate", !1), c && b.prop("checked", !0).prop("indeterminate", !1).removeClass("indeterminate"), f.apply(b)
                }
            };
            a('input[type="checkbox"]', d).on("click", f), a('input[type="checkbox"].leaf', d).each(function() {
                f.apply(this)
            })
        }
    }
}(jQuery);